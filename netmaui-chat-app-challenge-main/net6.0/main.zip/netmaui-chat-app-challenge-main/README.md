# Chat App - .NET MAUI UI Challenge

Chat App UI Challenge made with .NET MAUI.

![Chat App](images/chatapp-maui.png)

Based on this [design](https://dribbble.com/shots/11470136-A-Messaging-App-Concept) by [Tannaz Sadeghi](https://dribbble.com/tannazsadeghi).