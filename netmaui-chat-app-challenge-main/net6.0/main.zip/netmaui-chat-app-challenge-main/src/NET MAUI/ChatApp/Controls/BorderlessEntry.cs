﻿namespace ChatApp.Controls
{
    public class BorderlessEntry : Entry
    {

    }
}
