﻿namespace ChatApp.Views.Templates
{
    public partial class SenderChatMessageItemTemplate : ContentView
    {
        public SenderChatMessageItemTemplate()
        {
            InitializeComponent();
        }
    }
}