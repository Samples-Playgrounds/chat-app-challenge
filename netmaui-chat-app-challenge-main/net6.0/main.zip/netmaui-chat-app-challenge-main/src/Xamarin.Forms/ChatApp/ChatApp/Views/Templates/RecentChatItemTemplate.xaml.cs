﻿using Xamarin.Forms;

namespace ChatApp.Views.Templates
{
    public partial class RecentChatItemTemplate : ContentView
    {
        public RecentChatItemTemplate()
        {
            InitializeComponent();
        }
    }
}