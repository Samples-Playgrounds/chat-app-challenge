﻿using Xamarin.Forms;

namespace ChatApp.Controls
{
    public class BorderlessEntry : Entry
    {

    }
}
