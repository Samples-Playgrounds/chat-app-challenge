﻿using Xamarin.Forms;

namespace ChatApp.Views.Templates
{
    public partial class ReceiverChatMessageItemTemplate : ContentView
    {
        public ReceiverChatMessageItemTemplate()
        {
            InitializeComponent();
        }
    }
}