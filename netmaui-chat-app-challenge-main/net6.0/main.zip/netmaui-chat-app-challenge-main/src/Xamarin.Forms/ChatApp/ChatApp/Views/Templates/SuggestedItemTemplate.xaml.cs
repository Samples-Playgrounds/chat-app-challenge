﻿using Xamarin.Forms;

namespace ChatApp.Views.Templates
{
    public partial class SuggestedItemTemplate : ContentView
    {
        public SuggestedItemTemplate()
        {
            InitializeComponent();
        }
    }
}